/**
 * Created by James on 2/7/2015.
 */
import javax.swing.*;




public class Main {
    public static void main(String[] args) {

        GameGui gui = new GameGui();
        gui.createGui();



    }

}