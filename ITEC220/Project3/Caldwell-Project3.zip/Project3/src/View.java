/**
 * @author James Caldwell
 * @version April 6th
 */
public class View {



    public View(){


       getYesNoDialog();

   }

    public static  void getYesNoDialog(){

        YesNoDialog dialog = new YesNoDialog();
        dialog.pack();
        dialog.setLocationRelativeTo(null);
        dialog.setVisible(true);




    }

    public static  void getLoadPoS(){

       LoadPos dialog2 = new LoadPos();
       dialog2.pack();
       dialog2.setLocationRelativeTo(null);
       dialog2.setVisible(true);
    }

    public static   void getConcen(){

      Concentration dialog3 = new Concentration();
      dialog3.pack();
      dialog3.setLocationRelativeTo(null);
      dialog3.setVisible(true);
    }

    public static void getMain(){

        MainWindow dialog4 = new MainWindow();
        dialog4.pack();
        dialog4.setLocationRelativeTo(null);
        dialog4.setVisible(true);

    }
}
