import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

/**
 * @author James Caldwell
 * @version April 6th
 */
public class Semester implements Serializable {

    private List<Course> classList;
    private int semester;

    public Semester(int _semester){

       this.semester = _semester;
       classList =  new LinkedList<Course>();



    }


    public int getSemNo(){

        return semester;
    }


    public void addCourse(Course course)
    {
        if (course != null)
            classList.add(course);
    }

    public String toString()
    {
        String result = "";
        for (Course course : classList)
            result += course + "\n";
        return result;
    }

    public Course find(String _title, int _courseNo)
    {
        for (Course course : classList)
            if (_title.equals(course.getTitle()) &&
                    _courseNo == course.getCourseNo())
                return course;

        return null;
    }

}
