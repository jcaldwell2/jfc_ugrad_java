/**
 * @author James Caldwell
 * @version April 6th.
 */
public class POSDriver {

    public static void main(String[] args) throws Exception{


        new Controller().start();

    }
}
