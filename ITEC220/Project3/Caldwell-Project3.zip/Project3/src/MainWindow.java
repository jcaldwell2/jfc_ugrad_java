/**
 * @author James Caldwell
 * @version April 6th
 */

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainWindow extends JDialog {
    private JPanel contentPane;
    private JButton findACourseButton;
    private JButton addACourseButton;
    private JButton removeACourseButton;
    private JButton addAGradeButton;
    private JButton viewCourseButton;
    private JButton viewProgramOfStudyButton;
    private JButton saveProgramOfStudyButton;
    private JTextArea mainDisplay;
    private JButton exitButton;

    private Concentration concentrate = new Concentration();


    public MainWindow() {
        setContentPane(contentPane);
        setModal(true);

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        viewProgramOfStudyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainDisplay.setText(concentrate.getData());
            }
        });
    }
}
