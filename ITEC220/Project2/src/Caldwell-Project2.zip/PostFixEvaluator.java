/**
 * @author James Caldwell
 * @version 3/5/2015
 */
public class PostFixEvaluator {


    public static void main(String args[]){

        View gui = new View();





    }
}
